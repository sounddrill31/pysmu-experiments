# Programming for the ADALM1000 in Python
# EE1103L Electronics Lab - Addon Module
# BS in Electronic Systems - IIT Madras
# Course Instructor : Dr.Janakiraman Viraraghavan
# Control Code by Aditya Rao, 23f3000019@es.study.iitm.ac.in
# April 2024
# Github : https://github.com/aditya-rao-iit-m/adalm1000
# GNU GPL v3.0

from .ar_iitm import *
