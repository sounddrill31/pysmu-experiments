# Programming for the ADALM1000 in Python
# EE1103L Electronics Lab - Addon Module
# BS in Electronic Systems - IIT Madras
# Course Instructor : Dr.Janakiraman Viraraghavan
# Control Code by Aditya Rao, 23f3000019@es.study.iitm.ac.in
# April 2024
# Github : https://github.com/aditya-rao-iit-m/adalm1000
# GNU GPL v3.0

import time, tempfile, os
class ar_iitm_adalm1000_info():
        def show_message(header,footer):
            print (' ')
            print ('-----------------------------------------------------------')
            print ('ADALM1000 - Digital Pin Interface')
            print ('EE1103L - Electronics Lab - April 2024')
            print ('Course Instructor - Dr.Janakiraman Viraraghavan')
            print ('-----------------------------------------------------------')
            print (' ')
            print (header)
            print (' ')
            print ('-----------------------------------------------------------')
            print ('ADALM1000 M1K - Analog Devices - Control Code by: ')
            print ('Aditya Rao')
            print ('23f3000019@es.study.iitm.ac.in')
            print ('BS in Electronic Systems')
            print ('IIT Madras')
            print ('-----------------------------------------------------------')
            print (' ')
            print (footer)
            print (' ')
            print ('-----------------------------------------------------------')
            print (' ')
            
class ar_iitm_adalm1000_pin():
        def pio0_low(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x50, 28, 0, 0, 0, 100)
            time.sleep(zzz)
        def pio0_high(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x51, 28, 0, 0, 0, 100)
            time.sleep(zzz)
        def pio1_low(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x50, 29, 0, 0, 0, 100)
            time.sleep(zzz)
        def pio1_high(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x51, 29, 0, 0, 0, 100)
            time.sleep(zzz)
        def pio2_low(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x50, 47, 0, 0, 0, 100)
            time.sleep(zzz)
        def pio2_high(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x51, 47, 0, 0, 0, 100)
            time.sleep(zzz)
        def pio3_low(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x50, 3, 0, 0, 0, 100)
            time.sleep(zzz)
        def pio3_high(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x51, 3, 0, 0, 0, 100)
            time.sleep(zzz)
        def red_led_low(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x50, 0, 0, 0, 0, 100)
            time.sleep(zzz)
        def red_led_high(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x51, 0, 0, 0, 0, 100)
            time.sleep(zzz)
        def green_led_low(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x50, 2, 0, 0, 0, 100)
            time.sleep(zzz)
        def green_led_high(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x51, 2, 0, 0, 0, 100)
            time.sleep(zzz)
        def blue_led_low(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x50, 1, 0, 0, 0, 100)
            time.sleep(zzz)
        def blue_led_high(adalm1000,zzz):
            adalm1000.ctrl_transfer(0x40, 0x51, 1, 0, 0, 0, 100)
            time.sleep(zzz)
